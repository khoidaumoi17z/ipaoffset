# iOS Offset Desk — bản ứng dụng iPhone

## Trạng thái bàn giao

Đây là dự án iOS hoàn chỉnh ở dạng mã nguồn + workflow build. Phiên làm việc hiện tại chạy Linux, không có macOS/Xcode, nên chưa tạo được executable iOS hoặc IPA đã biên dịch. Không có file IPA giả hay archive chỉ đổi đuôi.

Chưa kiểm thử bằng iOS Simulator hoặc iPhone. Giữ nguyên byte-for-byte `core.js` từ bản Windows; phần tích hợp chọn file, clipboard và xuất file được thay bằng API iOS. Điều này bảo toàn logic hiện có, nhưng chưa đủ để bảo đảm toàn bộ hành vi trên thiết bị.

## Chức năng được đưa vào bản iOS

| Chức năng Windows | Bản iOS |
|---|---|
| Đọc Mach-O ARM64/thin/FAT | Giữ nguyên parser |
| Đọc dump C `sub_HEX/FUN_HEX` | Giữ nguyên parser |
| VA/RVA/file offset/slice offset | Giữ nguyên cách tính |
| Ghép dump theo VA | Giữ nguyên logic và cảnh báo |
| Chọn/lọc hàm, xem thân hàm | Giữ giao diện, tự co theo màn hình |
| Xuất CSV/JSON/.mm | Ghi file tạm và mở bảng chia sẻ iOS để Lưu vào Tệp |
| Copy mã | UIPasteboard của iOS |
| Sinh khung Dobby | Giữ nguyên bộ sinh mã, cần người dùng nhập ABI |
| Chọn file | UIDocumentPicker của iOS |
| Hoạt động offline | HTML/JS được đóng gói trong app, không tải từ website |

App không tự tìm antiban, không chạy hook vào game và không dump game đã cài. Giới hạn có sẵn về ARM64e/PAC, mã hóa, chữ ký hàm và metadata vẫn giữ nguyên.

## Build IPA bằng Windows và GitHub Actions

Bạn cần đúng hai file đã được cung cấp:

1. `iOS-Offset-Desk-iPhone-Source.zip` — upload nguyên ZIP, không cần giải nén.
2. `build-iOS-Offset-Desk-IPA.yml` — đặt vào `.github/workflows/build-ipa.yml`.

Các bước:

1. Tạo một repository GitHub do bạn quản lý. Repository private hoặc public đều được; quyền dùng Actions/runner phụ thuộc tài khoản và chính sách GitHub.
2. Trong repository, **Add file → Upload files**, upload `iOS-Offset-Desk-iPhone-Source.zip` vào thư mục gốc rồi commit.
3. **Add file → Create new file**, nhập đường dẫn `.github/workflows/build-ipa.yml`.
4. Mở file YML được cung cấp bằng Notepad, copy toàn bộ nội dung vào file trên GitHub rồi commit vào nhánh mặc định.
5. Vào **Actions → Build iOS Offset Desk IPA → Run workflow**.
6. Workflow chạy trên macOS, tự giải nén source, tạo project bằng XcodeGen và dùng Xcode build bản ARM64.
7. Khi run thành công, mở run, kéo xuống **Artifacts**, tải `iOS-Offset-Desk-unsigned-IPA`.
8. Giải nén artifact. File kết quả là `iOS-Offset-Desk-unsigned.ipa`.
9. IPA này chưa có chữ ký/provisioning hợp lệ. Cần ký bằng tài khoản/chứng chỉ và phương thức cài IPA phù hợp của bạn trước khi cài lên iPhone thường. Workflow không chứa chứng chỉ và không tự ký bằng tài khoản của bạn.

Nếu workflow lỗi, đọc step đỏ và tải log. Source chưa qua build thực tế trong phiên này, nên lỗi Xcode có thể cần sửa sau khi có log. Mốc hoàn tất xác minh là build thành công và thử chức năng trên iPhone, không phải chỉ có ZIP source.

## Build bằng Mac/Xcode nếu có

1. Giải nén source và vào thư mục `iOSOffsetDesk`.
2. Cài Xcode và XcodeGen theo hướng dẫn chính thức.
3. Chạy `xcodegen generate --spec project.yml`.
4. Mở `iOSOffsetDesk.xcodeproj`, chọn scheme `iOSOffsetDesk`.
5. Chọn Apple Developer Team và đổi bundle identifier nếu cần.
6. Build/Run lên iPhone, hoặc Archive/Export theo provisioning của bạn.

## Sử dụng trên iPhone sau khi cài

1. Đặt file Mach-O và dump C trong **Tệp → Trên iPhone của tôi** hoặc thư mục iCloud đã tải xuống.
2. Mở **iOS Offset Desk**.
3. Bấm **Mở Mach-O iOS**, chọn executable/thư viện cần phân tích. Không chọn IPA nguyên gói.
4. Bấm **Mở dump C / SO.C** nếu có dump cùng phiên bản.
5. Chọn hàm để xem VA, RVA, file offset, nguồn và phần thân.
6. Bấm **Xuất toàn bộ CSV** hoặc **Xuất báo cáo JSON**; trong bảng chia sẻ chọn **Lưu vào Tệp**.
7. Để sinh mã, nhập image, kiểu trả về và tham số đã xác minh, chọn hành vi rồi bấm **Sinh mã .mm**.
8. Bấm **Tải mã đã sinh → Lưu vào Tệp**, hoặc **Copy mã**.

File lớn có thể làm iOS thiếu bộ nhớ. Vẫn áp dụng giới hạn Windows (Mach-O 512 MiB, dump 100 MiB), nhưng đây là giới hạn đầu vào, không phải cam kết iPhone xử lý được mọi file trong giới hạn. Nên thử file nhỏ trước. Phiên phân tích không được tự lưu; xuất báo cáo trước khi đóng app.

## Kiểm tra sau khi build

- App mở giao diện dù bật chế độ máy bay.
- **Dùng mẫu minh họa** hiện hai hàm, lọc và CSV/JSON hoạt động.
- Import cùng một Mach-O/dump trên Windows và iPhone; các giá trị VA/RVA/file offset khớp nhau.
- Sinh `.mm` với cùng chữ ký/image/hành vi; nội dung mã khớp bản Windows.
- Export CSV/JSON/.mm vào Tệp; mở lại để kiểm tra nội dung.
- Copy mã rồi dán vào ứng dụng ghi chú.
- Thử hủy picker, file lỗi, cryptid và ARM64e: cảnh báo đúng, không sinh offset giả.

## Kiểm thử đã thực hiện ở môi trường phát triển

Parser Windows và bản iOS có hash giống nhau. Có kiểm thử bằng fixture cho parser và bằng DOM mô phỏng cho bridge: nạp file theo chunk, ghép dump, sinh mã giống nhau, export/copy và lỗi nhập. Chưa biên dịch Swift bằng iOS SDK, chưa kiểm thử giao diện WebKit thật hoặc signing trên thiết bị.

Nguồn: [Apple WKScriptMessageHandler](https://developer.apple.com/documentation/webkit/wkscriptmessagehandler), [UIDocumentPickerViewController](https://developer.apple.com/documentation/uikit/uidocumentpickerviewcontroller), [XcodeGen](https://github.com/yonaskolb/XcodeGen), [GitHub workflow artifacts](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/download-workflow-artifacts).
